#include "syscall.h"

void print(char c, int n){
        int i;
        for (i = 0; i < n; i++) {
            PutChar(c + i);
        }
        PutChar('\n');
}

int  main(){
    print('a',4);
    return 0;
}

//Ici nous avons enlever Halt() à la fin, il ne doit donc pas avoir d'erreur 
//lorsque ce fichier est appelé avec ./userprog/nachos -x test/putchar