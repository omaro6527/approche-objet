#include "syscall.h"
//Test II.3 - Multiple threads (test with loop)
/*
Ce test vérifie que notre système peut créer plusieurs threads utilisateur
simultanément et qu'ils s'exécutent tous correctement avec une boucle et ecrit des a 
dans chaque thread afin de voir si l'ordonnancement fonctionne et que chaque thread 
ecit bien les 10 'a' avant de terminer.
on le lance avec la commande :
./nachos -rs 1234 -x ../test/multithread_loop
*/
void worker_with_loop(void *arg) {
    volatile int i;  
    int id = (int)arg;
    int count = 0;
    
    PutString("Thread ");
    PutChar('0' + id);
    PutString(": Start\n");
    
    for (i = 0; i < 10; i++) {
        PutChar('a');
        count++;
    }
    
    PutString(" Count=");
    PutChar('0' + (count / 10));
    PutChar('0' + (count % 10));
    PutChar('\n');
    
    ThreadExit();
}

int main() {
    PutString(" Thread avec loop\n");
    
    ThreadCreate(worker_with_loop, (void*)1, ThreadExit);
    ThreadCreate(worker_with_loop, (void*)2, ThreadExit);
    ThreadCreate(worker_with_loop, (void*)3, ThreadExit);
    
    PutString("Main: Exiting\n");
    ThreadExit();
    
    return 0;
}