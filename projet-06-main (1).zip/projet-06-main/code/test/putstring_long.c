#include "syscall.h"

#ifndef MAXN
#define MAXN 256
#endif

#define LONGN (MAXN * 3)

static char big[LONGN];

int main(void) {
    int i;    

    for (i = 0; i < LONGN - 1; i++) {
        big[i] = (char)((i % 26) + 'a');
    }
    big[LONGN - 1] = '\0';

    PutString(big);
    PutString("\n[END]\n");
    return 0;
}


//Ici nous avons testons la méthode PutString avec des chaînes plus longues que le tampon utilisé
//lorsque ce fichier est appelé avec ./userprog/nachos -x test/putstring_long,