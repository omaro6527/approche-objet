#include "syscall.h"

void worker(void *arg)
{
    PutChar('A');
    ThreadExit();
}

int main(void)
{
    ThreadCreate(worker, 0, ThreadExit);

    while (1) {}

    return 0;
}
