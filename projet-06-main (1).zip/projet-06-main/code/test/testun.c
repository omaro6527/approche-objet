/*
  Test II.1 - Protection de la console avec verrous
  
  OBJECTIF :
  Démontrer que les verrous sur PutString et GetString empêchent
  l'entrelacement des messages et les crashs lors d'accès concurrents
  à la console.
  
    ./nachos -rs 1234 -x ../test/testun 
 */

#include "syscall.h"

void worker(void *arg) {
    int id = (int)arg;
    int i;
    
    for (i = 0; i < 3; i++) {
        PutString("Thread ");
        PutChar('0' + id);
        PutString(" : Message numero ");
        PutChar('0' + i);
        PutString("\n");
    }
    
    ThreadExit();
}

int main() {
    PutString("=== Test II.1 : Protection de la console ===\n");
    PutString("Creation de 3 threads qui affichent simultanement\n\n");
    
    ThreadCreate(worker, (void*)1,ThreadExit);
    ThreadCreate(worker, (void*)2,ThreadExit);
    ThreadCreate(worker, (void*)3,ThreadExit);
    
    PutString("\nMain: Exiting\n");
    ThreadExit();
    
    return 0;
}