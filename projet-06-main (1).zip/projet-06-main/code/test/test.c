#include "syscall.h"
/* 
 Test II.2 - Grand nombre de threads
  
OBJECTIF :
    Vérifier que Nachos se termine automatiquement lorsque tous les threads
    (y compris le thread principal) appellent ThreadExit(). 
    d'ou le putString final qui ne doit jamais s'afficher.


    ./nachos -rs 1234 -x ../test/test
*/

void simple_thread(void *arg) {
    int id = (int)arg;
    
    PutString("Thread ");
    PutChar('0' + id);
    PutString(" running\n");
    
    ThreadExit();
}

int main() {
    PutString("=== Test II.2: Thread counting ===\n");
    PutString("Main: Creating 2 threads\n");
    
    ThreadCreate(simple_thread, (void*)1, ThreadExit);
    ThreadCreate(simple_thread, (void*)2, ThreadExit);
    
    PutString("Main: Calling ThreadExit\n");
    ThreadExit();
    
    PutString("ERROR: Main still running after ThreadExit!\n");
    
    return 0;
}