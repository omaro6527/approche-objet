/*
  Test II.4 - Grand nombre de threads
  
  OBJECTIF :
  Démontrer le comportement du système lorsqu'on tente de créer
  plus de threads que de slots disponibles.

  ./nachos -rs 1234 -x ../test/test_threads

 */

#include "syscall.h"

void worker(void *arg) {
    int id = (int)arg;
    volatile int i;
    
    PutString("Thread ");
    PutChar('0' + (id / 10));
    PutChar('0' + (id % 10));
    PutString(" started\n");
    
    for (i = 0; i < 3; i++) {
        PutChar('.');
    }
    PutChar('\n');
    
    ThreadExit();
}

int main() {
    int i;
    
    PutString("=== Test II.4 : Grand nombre de threads ===\n");
    
    // Créer 8 threads (bien plus que les 3 slots disponibles)
    for (i = 1; i <= 8; i++) {
        ThreadCreate(worker, (void*)i, ThreadExit);
    }
    
    PutString("Main exiting\n");
    ThreadExit();
    
    return 0;
}