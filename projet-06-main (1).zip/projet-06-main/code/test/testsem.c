/*
  Test IV.1 - Producteur-Consommateur avec sémaphores
  un producteur et un consommateur partagent un tampon circulaire de taille fixe (BUFFER_SIZE)
  synchronisé par empty/full (compteur de places) et m (mutex).
  Le test vérifie que les insertions/extractions s’enchaînent sans débordement.
  

  ./nachos -rs 1234 -x ../test/testsem
  */

#include "syscall.h"

#define BUFFER_SIZE 3
#define NUM_ITEMS 5

int buffer[BUFFER_SIZE];
int in = 0;
int out = 0;

sem_t m;
sem_t empty;
sem_t full;

void producer(void *arg) {
    int id = (int)arg;
    int i;
    int item;
    
    for (i = 0; i < NUM_ITEMS; i++) {
        item = id * 100 + i;
        
        SemP(empty);
        SemP(m);
        
        buffer[in] = item;
        in = (in + 1) % BUFFER_SIZE;
        
        PutString("Producer ");
        PutChar('0' + id);
        PutString(" produced item\n");
        
        SemV(m);
        SemV(full);
    }
    
    ThreadExit();
}

void consumer(void *arg) {
    int id = (int)arg;
    int i;
    int item;
    
    for (i = 0; i < NUM_ITEMS; i++) {
        SemP(full);
        SemP(m);
        
        item = buffer[out];
        out = (out + 1) % BUFFER_SIZE;
        
        PutString("Consumer ");
        PutChar('0' + id);
        PutString(" consumed item\n");
        
        SemV(m);
        SemV(empty);
    }
    
    ThreadExit();
}

int main() {
    PutString("=== Producteur-Consommateur ===\n");
    
    m = SemCreate(1);
    empty = SemCreate(BUFFER_SIZE);
    full = SemCreate(0);
    
    if (m < 0 || empty < 0 || full < 0) {
        PutString("ERROR: Failed to create semaphores\n");
        ThreadExit();
    }
    
    PutString("Creating producer and consumer\n");
    
    ThreadCreate(producer, (void*)1,ThreadExit);
    ThreadCreate(consumer, (void*)1,ThreadExit);
    
    PutString("Main exiting\n");
    ThreadExit();
    
    return 0;
}