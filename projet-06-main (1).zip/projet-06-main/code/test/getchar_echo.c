#include "syscall.h"
int main() {
    int c = GetChar();
    if (c >= 0) PutString("lu: "), PutChar((char)c), PutChar('\n');
    else PutString("EOF\n");
    return 0;
}

// appeler ce test depuis la base code du projet avec la commande ./userprog/nachos -x test/getchar_echo
//Ce test doit renvoyer tout caractère entrée dans le terminal.
