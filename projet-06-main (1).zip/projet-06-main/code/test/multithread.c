#include "syscall.h"
//Test II.3 - Multiple threads (test simple)
/*
Ce test vérifie que notre système peut créer plusieurs threads utilisateur
simultanément et qu'ils s'exécutent tous correctement. Il teste également
que le compteur de threads fonctionne et que Nachos se termine
automatiquement quand tous les threads ont appelé ThreadExit.
on le lance avec la commande :
./nachos -rs 1234 -x ../test/multithread 

*/ 
void simple_worker(void *arg) {
    int id = (int)arg;
    
    PutString("Thread ");
    PutChar('0' + id);
    PutString(" is running\n");
    
    ThreadExit();
}

int main() {
    PutString("Multiple threads\n");
    
    PutString("Creating thread 1\n");
    ThreadCreate(simple_worker, (void*)1, ThreadExit);
    
    PutString("Creating thread 2\n");
    ThreadCreate(simple_worker, (void*)2, ThreadExit);
    
    PutString("Creating thread 3\n");
    ThreadCreate(simple_worker, (void*)3, ThreadExit);
    
    PutString("Maintenant que les threads sont cree on Exit\n");
    ThreadExit();
    
    return 0;
}