#include "syscall.h"

//Test pour PutString
int main() {
    PutString("Hello World!\n");
    PutString("test\n");     
    PutString("");          
    return 0;
}

//Ici nous avons testons la méthode PutString avec des chaînes courtes et le cas de la chaîne vide
//lorsque ce fichier est appelé avec ./userprog/nachos -x test/putstring,
// le résultat attendu est donc que la console renvoie "<Hello World!" suivi de "<test>" puis "<>".