#include "usersem.h"

UserSemaphore::UserSemaphore(int initialValue, int semId) {
    kernelSem = new Semaphore("user semaphore", initialValue);
    id = semId;
}

UserSemaphore::~UserSemaphore() {
    delete kernelSem;
}

void UserSemaphore::P() {
    kernelSem->P();
}

void UserSemaphore::V() {
    kernelSem->V();
}