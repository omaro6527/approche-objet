#ifndef USERSEM_H
#define USERSEM_H

#include "synch.h"
class UserSemaphore {
  private:
    Semaphore *kernelSem;
    int id;
  public:
    UserSemaphore(int initialValue, int semId);
    ~UserSemaphore();
    void P();
    void V();
    int GetId() { return id; }
};
#endif 