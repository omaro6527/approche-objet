// exception.cc
//      Entry point into the Nachos kernel from user programs.
//      There are two kinds of things that can cause control to
//      transfer back to here from user code:
//
//      syscall -- The user code explicitly requests to call a procedure
//      in the Nachos kernel.  Right now, the only function we support is
//      "Halt".
//
//      exceptions -- The user code does something that the CPU can't handle.
//      For instance, accessing memory that doesn't exist, arithmetic errors,
//      etc.
//
//      Interrupts (which can also cause control to transfer from user
//      code into the Nachos kernel) are handled elsewhere.
//
// For now, this only handles the Halt() system call.
// Everything else core dumps.
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation
// of liability and disclaimer of warranty provisions.

#include "copyright.h"
#include "system.h"
#include "syscall.h"
#ifdef CHANGED
#include "userthread.h"
#include "usersem.h"
static unsigned copyStringFromMachine(int from, char *to, unsigned size);
static unsigned copyStringToMachine(const char *from, int to, unsigned size);

#define MAX_SEMS 10
static UserSemaphore* semTable[MAX_SEMS] = {NULL};
#endif

//----------------------------------------------------------------------
// UpdatePC : Increments the Program Counter register in order to resume
// the user program immediately after the "syscall" instruction.
//----------------------------------------------------------------------
static void
UpdatePC ()
{
    int pc = machine->ReadRegister (PCReg);
    machine->WriteRegister (PrevPCReg, pc);
    pc = machine->ReadRegister (NextPCReg);
    machine->WriteRegister (PCReg, pc);
    pc += 4;
    machine->WriteRegister (NextPCReg, pc);
}


//----------------------------------------------------------------------
// ExceptionHandler
//      Entry point into the Nachos kernel.  Called when a user program
//      is executing, and either does a syscall, or generates an addressing
//      or arithmetic exception.
//
//      For system calls, the following is the calling convention:
//
//      system call code -- r2
//              arg1 -- r4
//              arg2 -- r5
//              arg3 -- r6
//              arg4 -- r7
//
//      The result of the system call, if any, must be put back into r2.
//
// And don't forget to increment the pc before returning. (Or else you'll
// loop making the same system call forever!
//
//      "which" is the kind of exception.  The list of possible exceptions
//      are in machine.h.
//----------------------------------------------------------------------

void
ExceptionHandler (ExceptionType which)
{
    int type = machine->ReadRegister (2);
    int address = machine->ReadRegister (BadVAddrReg);

    switch (which)
      {
        case SyscallException:
          {
            switch (type)
              {
                case SC_Halt:
                  {
                    DEBUG ('s', "Shutdown, initiated by user program.\n");
                    interrupt->Powerdown ();
                    break;
                  }
                  #ifdef CHANGED
                case SC_PutChar:
                  {
                    DEBUG('s',"PutChar.\n");
                    consoledriver->PutChar((char)machine->ReadRegister(4));
                    break;}

                case SC_PutString: 
                  {
                    DEBUG('s', "PutString (Tronqué)\n");
                    int uaddr = machine->ReadRegister(4);
                    char *kbuf = new char[MAX_STRING_SIZE];

                    while (true){
                      unsigned copie = copyStringFromMachine(uaddr, kbuf, MAX_STRING_SIZE);
                      consoledriver->PutString(kbuf);

                      if (copie < MAX_STRING_SIZE -1 || copie == 0){
                        break;
                      }

                      uaddr += copie;
                    }
                    
                    delete[] kbuf;
                    break;
                  }
                case SC_Exit: 
                  {
                    int status = machine->ReadRegister(4);
                    DEBUG('s',"Exit %d\n", status);
                    interrupt->Powerdown();
                    break;
                  }
                case SC_GetChar:
                  {
                    DEBUG('s',"GetChar.\n");
                    int c = consoledriver->GetChar();
                    machine->WriteRegister(2, (int)c);
                    break;
                  }
                
                case SC_GetString:
                  {
                    int uadrr = machine->ReadRegister(4);
                    int n = machine->ReadRegister(5);

                    if (n<=0){
                      break;
                    }

                    //Tampon noyau
                    int kmax = n;
                    if (kmax < 2){
                      kmax = 2;
                    }
                    char *kbuf = new char[kmax];

                    consoledriver->GetString(kbuf, kmax);
                    (void) copyStringToMachine(kbuf, uadrr, (unsigned)n);

                    delete[] kbuf; //On désalloue
                    break;
                  }
                case SC_PutInt:
                {
                  int val = machine->ReadRegister(4);
                  char buf[32];
                  snprintf(buf, sizeof(buf), "%d", val);
                  consoledriver->PutString(buf);
                  break;
                }
                case SC_ThreadCreate:
                {
                  int f = machine->ReadRegister(4);
                  int arg = machine->ReadRegister(5);
                  int texit = machine->ReadRegister(6);
                  //On vérifie que les arguments coté utilisateur arrivent bien
                  // et que le PC/SP du thread appelant sont cohérents.
                  DEBUG('x', "[SC_ThreadCreate] caller='%s' f=0x%x arg=0x%x PC=0x%x SP=0x%x\n",
                    currentThread->getName(), f, arg,
                    machine->ReadRegister(PCReg),
                    machine->ReadRegister(StackReg));
                  do_ThreadCreate(f, arg, texit);
                  break;
                }
                case SC_ThreadExit:
                {
                  DEBUG('x', "[SC_ThreadExit] caller='%s' PC=0x%x SP=0x%x\n",
                    currentThread->getName(),
                    machine->ReadRegister(PCReg),
                    machine->ReadRegister(StackReg));
                  do_ThreadExit();
                  break;
                }
                case SC_SemCreate:
                {
                  int initialValue = machine->ReadRegister(4);
                  int semId = -1;
                  for (int i = 0; i < MAX_SEMS; i++) {
                    if (semTable[i] == NULL) {
                      semId = i;
                      break;
                    }
                  }
    
                  if (semId != -1) {
                    semTable[semId] = new UserSemaphore(initialValue, semId);
                  }
    
                  machine->WriteRegister(2, semId);  // Retourner l'ID
                  break;
                  }
                case SC_SemP:
                {
                  int semId = machine->ReadRegister(4);
                  if (semId >= 0 && semId < MAX_SEMS && semTable[semId] != NULL) {
                    semTable[semId]->P();
                  }
                  break;
                }

                case SC_SemV:
                {
                  int semId = machine->ReadRegister(4);
                  if (semId >= 0 && semId < MAX_SEMS && semTable[semId] != NULL) {
                    semTable[semId]->V();
                  }
                  break;
                }
                #endif
                default:
                  {
                    ASSERT_MSG(FALSE, "Unimplemented system call %d\n", type);
                  }
              }

            // Do not forget to increment the pc before returning!
            // This skips over the syscall instruction, to continue execution
            // with the rest of the program
            UpdatePC ();
            break;
          }

        case PageFaultException:
          if (!address) {
            ASSERT_MSG (FALSE, "NULL dereference at PC %x!\n", machine->registers[PCReg]);
          } else {
            // For now
            ASSERT_MSG (FALSE, "Page Fault at address %x at PC %x\n", address, machine->registers[PCReg]);
          }
          break;

        case ReadOnlyException:
          // For now
          ASSERT_MSG (FALSE, "Read-Only at address %x at PC %x\n", address, machine->registers[PCReg]);
          break;

        case BusErrorException:
          // For now
          ASSERT_MSG (FALSE, "Invalid physical address at address %x at PC %x\n", address, machine->registers[PCReg]);
          break;

        case AddressErrorException:
          // For now
          ASSERT_MSG (FALSE, "Invalid address %x at PC %x\n", address, machine->registers[PCReg]);
          break;

        case OverflowException:
          // For now
          ASSERT_MSG (FALSE, "Overflow at PC %x\n", machine->registers[PCReg]);
          break;

        case IllegalInstrException:
          // For now
          ASSERT_MSG (FALSE, "Illegal instruction at PC %x\n", machine->registers[PCReg]);
          break;

        default:
          ASSERT_MSG (FALSE, "Unexpected user mode exception %d %d %x at PC %x\n", which, type, address, machine->registers[PCReg]);
          break;
      }
}

#ifdef CHANGED
static unsigned copyStringFromMachine(int from, char *to, unsigned size) {
    if (to == nullptr || size == 0) return 0;

    unsigned i = 0;
    int tmp = 0;
    bool ok = true;

    while (i + 1 < size) {
        ok = machine->ReadMem(from + i, 1, &tmp);  
        if (!ok) break;
        char c = (char)(tmp & 0xFF);

        to[i++] = c;
        if (c == '\0') {
            to[i-1] = '\0';
            return i - 1;   
        }
    }

    to[i] = '\0';
    return i;
}

static unsigned copyStringToMachine(const char *from, int to, unsigned size){
  if (from == nullptr || size == 0){
    unsigned i = 0;
    
    while (i + 1 < size){
      char c = from[i];
      if (!machine->WriteMem(to + i, 1, (int)(unsigned char)c)){
        break;
      }
      i++;
      if (c == '\0'){
        return i-1;
      }
    }
    machine->WriteMem(to + i, 1, 0);
    return i;
  }
}
#endif 

