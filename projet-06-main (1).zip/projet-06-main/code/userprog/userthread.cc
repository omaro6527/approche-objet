#ifdef CHANGED
#include "system.h"
#include "userthread.h"
#include "addrspace.h"


struct Schmurtz{
    int f;
    int arg;
    int texit;
};


int do_ThreadCreate(int f, int arg, int texit){

    //DEBUG : On vérifie que le nouvel objet Thread a bien le même AddrSpace
    // que le thread appelant et que shmurtz porte les bonnes valeurs

    DEBUG('x', "[do_ThreadCreate] from='%s' f=0x%x arg=0x%x\n",
        currentThread->getName(), f, arg);

    Thread *t = new Thread("user thread");

    Schmurtz *s = new Schmurtz;
    s->f = f;
    s->arg = arg;
    s->texit = texit;

    t->space = currentThread->space;
    currentThread->space->IncrementThreadCount();

    DEBUG('x', "[do_ThreadCreate] newThread='%s' space=%p schmurtz=%p\n",
        t->getName(), (void*)t->space, (void*)s);

    t->Start(StartUserThread, (void*) s);

    return 0;
}

void do_ThreadExit(void){

    DEBUG('x', "[do_ThreadExit] thread='%s' SP=0x%x\n",
        currentThread->getName(),
        machine->ReadRegister(StackReg),
        machine->ReadRegister(PCReg));
        currentThread->space->DecrementThreadCount();
    currentThread->Finish();

    ASSERT(FALSE);
}


void StartUserThread(void *schmurtz){

    Schmurtz *s = (Schmurtz *) schmurtz;

    DEBUG('x', "[StartUserThread] thread='%s' f=0x%x arg=0x%x\n",
        currentThread->getName(), s->f, s->arg);

    currentThread->space->InitRegisters();

    int userStack = currentThread->space->AllocateUserStack(); //Pile du thread

    if (userStack == -1) {
    DEBUG('x', "[StartUserThread] ERROR: No stack available\n");
    delete s;
    currentThread->space->DecrementThreadCount();
    currentThread->Finish();
    return;
    }

    DEBUG('x', "[StartUserThread] AllocateUserStack -> SP=0x%x\n", userStack);
    
    machine->WriteRegister(StackReg, userStack);

    machine->WriteRegister(PCReg, s->f); //Initialise le PC à l'adresse de la fonction user
    machine->WriteRegister(NextPCReg, s->f + 4);
    machine->WriteRegister(PrevPCReg, s->f - 4);
    machine->WriteRegister(4, s->arg); // passe l'arg à $a0
    machine->WriteRegister(RetAddrReg, s->texit);

    DEBUG('x', "[StartUserThread] Regs: PC=0x%x NextPC=0x%x PrevPC=0x%x SP=0x%x a0=0x%x\n",
        machine->ReadRegister(PCReg),
        machine->ReadRegister(NextPCReg),
        machine->ReadRegister(PrevPCReg),
        machine->ReadRegister(StackReg),
        machine->ReadRegister(4));
        machine->ReadRegister(RetAddrReg);

    currentThread->space->RestoreState();

    delete s;
    
    DEBUG('x', "[StartUserThread] machine->Run()\n");
    machine->Run();

    ASSERT(FALSE);
}

#endif