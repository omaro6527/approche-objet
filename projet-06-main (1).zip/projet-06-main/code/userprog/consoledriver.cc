#ifdef CHANGED
#include "copyright.h"
#include "system.h"
#include "consoledriver.h"
#include "synch.h"
static Semaphore *readAvail;
static Semaphore *writeDone;
static void ReadAvailHandler(void *arg) { (void) arg; readAvail->V(); }
static void WriteDoneHandler(void *arg) { (void) arg; writeDone->V(); }
ConsoleDriver::ConsoleDriver(const char *in, const char *out)
{
readAvail = new Semaphore("read avail", 0);
writeDone = new Semaphore("write done", 0);
console = new Console (in, out, ReadAvailHandler, WriteDoneHandler, NULL);
putLock = new Lock("put lock");
getLock = new Lock("get lock");
}
ConsoleDriver::~ConsoleDriver()
{
delete console;
delete writeDone;
delete readAvail;
delete putLock;
delete getLock;
}
void ConsoleDriver::PutChar(int ch)
{
    putLock->Acquire();
    if (ch == '\n'){
     console->TX(ch);
    writeDone->P();
    
    }
    else{
    console->TX('<');
    writeDone->P();
    console->TX(ch); 
    writeDone->P();
    console->TX('>'); 
    writeDone->P();   }   
    putLock->Release();
     return;
}
int ConsoleDriver::GetChar()
{
    getLock->Acquire();
    readAvail->P();
    getLock->Release();
    return console->RX();
}
void ConsoleDriver::PutString(const char *s)
{
    putLock->Acquire();
    if (!s) return;

    //Si chaine vide
    if (*s == '\0') {
        console->TX('<'); writeDone->P();
        console->TX('>'); writeDone->P();
        putLock->Release();
        return;
    }

    bool open = false;
    for (const char* p = s; *p; ++p) {
        char c = *p;

        if (!open) {
            console->TX('<');  writeDone->P();
            open = true;
        }

        if (c == '\n' || c == '\r') {
            //Pour fermer avant la ligne suivante
            console->TX('>');  writeDone->P();
            open = false;

            //Saut de ligne
            console->TX(c);    writeDone->P();
        } else {
            console->TX(c);    writeDone->P();
        }
    }

    if (open) {
        console->TX('>');      writeDone->P();
    }
    putLock->Release();
}
void ConsoleDriver::GetString(char *s, int n)
{
    getLock->Acquire();
    if (n <= 0 || s==NULL) {
        getLock->Release();
        return;
    }
    int i=0;
    while(i<n-1){
        int c = GetChar();
        if ( c == EOF) {
            break;
        }
        if(c=='\n'){
            s[i++]='\n';
            break;
        }
        s[i++] = (char)c;
    }
    s[i] = '\0';
    getLock->Release();
    return;
}
#endif // CHANGED