#ifdef CHANGED
void StartUserThread(void *schmurtz);
int do_ThreadCreate(int f, int arg, int texit);
void do_ThreadExit(void);
#endif